from django.contrib import admin
from django.urls import path,include
from forms_app import views

urlpatterns = [
    path('', views.user_form_view,name='users'),
]
