from django.shortcuts import render
from . import forms
# Create your views here.

def index(request):
    return render(request,'forms_app/index.html')

def form_name_view(request):
    form = forms.BasicInfo()
    
    if request.method=='POST':
        form = forms.BasicInfo(request.POST)
        if form.is_valid():
            print("Valid")
            print("name : ",form.cleaned_data.get('name'))
            print("email : ",form.cleaned_data.get('email'))
            print("text : ",form.cleaned_data.get('text'))
    else:
        pass
    
    return render(request,'forms_app/form_page.html',{'form':form})
    
def user_form_view(request):
    form = forms.UserInfoForm()
    
    if request.method=='POST':
        form = forms.UserInfoForm(request.POST)
        if form.is_valid():
            form.save(commit=True)
            print("Valid")
            print("first_name : ",form.cleaned_data.get('first_name'))
            print("last_name : ",form.cleaned_data.get('last_name'))
            print("email : ",form.cleaned_data.get('email'))
            return index(request)
        else:
            print("ERROR : Field data is invalid..")
    else:
        pass
    
    return render(request,'forms_app/users.html',{'form':form})
    #return render(request,'forms_app/.html',{'form':form})