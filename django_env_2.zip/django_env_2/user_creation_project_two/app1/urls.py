#from django.conf.urls import url
from app1 import views
from django.urls import path

urlpatterns = [
            path(r'^$',views.users,name='users'),
            
               ]