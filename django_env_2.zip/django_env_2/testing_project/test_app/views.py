from django.shortcuts import render
#importing loading from django template  
from django.template import loader  

# Create your views here.    
from django.http import HttpResponse, HttpResponseNotFound    
from django.views.decorators.http import require_http_methods    
from test_app.Forms import EmployeeForm
#D:\test_env\testing_project\test_app\form_for_file_upload.py
from test_app.function import handle_uploaded_file  
from test_app.form_for_file_upload import StudentForm  

@require_http_methods(["GET"])    
def hello(request):    
    return HttpResponse('<h1>This is Http GET request.</h1>')    
    
def index(request):  
    return render(request,'index.html')

def sample_template(request):  
   template = loader.get_template('sample_template.html') # getting our template  
   return HttpResponse(template.render())       # rendering the template in HttpResponse 
   
def sample_js(request):
    return render(request,'js_template.html')

def emp(request):  
    if request.method == "POST":  
        form = EmployeeForm(request.POST)  
        if form.is_valid():  
            try:  
                print(f"eid : {form.cleaned_data.get('eid')}")
                print(f"ename : {form.cleaned_data.get('ename')}")
                print(f"econtact : {form.cleaned_data.get('econtact')}")
                return redirect('/')  
            except:  
                pass  
    else:  
        form = EmployeeForm()  
    return render(request,'forms_template.html',{'form':form})

#D:\test_env\testing_project\test_app\templates\file_upload_template.html
def file_upload_method(request):  
    if request.method == 'POST':  
        student = StudentForm(request.POST, request.FILES)  
        if student.is_valid():  
            handle_uploaded_file(request.FILES['file'])  
            return HttpResponse("File uploaded successfuly")  
    else:  
        student = StudentForm()  
        return render(request,"file_upload_template.html",{'form':student}) 
        
def home_page(request):
    return render(request,"home.html")