from django.contrib import admin
from django.urls import path,include
from . import views

#TEMPLATE TAGGING
app_name = 'basicapp'

urlpatterns = [
    path('register/',views.register,name='register'),
    path('user_login/',views.login_function,name='user_login')
]
