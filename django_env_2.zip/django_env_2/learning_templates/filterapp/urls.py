from django.contrib import admin
from django.urls import path,include
from . import views

#TEMPLATE TAGGING
app_name = 'filterapp'

urlpatterns = [
    path('home/',views.home,name='home'),
]
