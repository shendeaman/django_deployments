from django.shortcuts import render

# Create your views here.
def home(request):
    context = {'text':"hello world!!!",'number':100}
    return render(request,'filterapp/home.html',context)