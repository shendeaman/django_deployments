#My custom filter
from django import template

register = template.Library()

@register.filter(value='cut')
def cut(value,arg):
    """
    This cut out all values of 'arg' from the string!
    """
    return value.replace(arg,'')
    
#register.filter('cut',cut)